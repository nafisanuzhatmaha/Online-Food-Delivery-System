module com.mycompany.onlinefooddelivery {
    requires javafx.controls;
    requires javafx.graphics;
    exports com.mycompany.onlinefooddelivery;
}