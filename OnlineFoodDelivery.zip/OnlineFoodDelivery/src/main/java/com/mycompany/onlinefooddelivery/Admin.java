package com.mycompany.onlinefooddelivery;

public class Admin extends User {

    public Admin(int userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    public void addRestaurant(Restaurant r) {
        System.out.println("Restaurant added: " + r.getName());
    }

    public void removeUser(User u) {
        System.out.println("User removed: " + u.name);
    }

    public void viewAllOrders() {
        System.out.println("Viewing all orders...");
    }
}