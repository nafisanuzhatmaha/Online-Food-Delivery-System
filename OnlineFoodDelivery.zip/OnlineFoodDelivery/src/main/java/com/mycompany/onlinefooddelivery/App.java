package com.mycompany.onlinefooddelivery;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class App extends Application {

    private Restaurant restaurant;
    private Cart cart;
    private Customer currentCustomer;

    @Override
    public void start(Stage stage) {
        // Initialize data
        setupDemoData();
        
        // Header
        Label title = new Label("Online Food Delivery");
        title.setStyle("-fx-font-size: 20px; -fx-text-fill: white;");

        HBox header = new HBox(title);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(15));
        header.setStyle("-fx-background-color: #3554B2;");

        // Main content
        Label welcome = new Label("Welcome to our platform!");
        welcome.setStyle("-fx-font-size: 18px;");

        Label description = new Label("Order food from your favorite restaurants.");
        description.setStyle("-fx-font-size: 14px;");
        
        // Menu display
        TextArea menuArea = new TextArea();
        menuArea.setEditable(false);
        menuArea.setPrefHeight(200);
        updateMenuDisplay(menuArea);
        
        // Order section
        TextField itemIdField = new TextField();
        itemIdField.setPromptText("Enter item ID to order");
        
        Button orderButton = new Button("Add to Cart");
        Button viewCartButton = new Button("View Cart");
        Button checkoutButton = new Button("Checkout");
        
        Label statusLabel = new Label();
        statusLabel.setTextFill(Color.GREEN);
        
        orderButton.setOnAction(e -> {
            try {
                int itemId = Integer.parseInt(itemIdField.getText());
                FoodItem selectedItem = findItemById(itemId);
                if (selectedItem != null) {
                    cart.addItem(selectedItem);
                    statusLabel.setText("Added: " + selectedItem.getName());
                    updateMenuDisplay(menuArea);
                } else {
                    statusLabel.setText("Item not found!");
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Enter valid item ID");
            }
            itemIdField.clear();
        });
        
        viewCartButton.setOnAction(e -> {
            StringBuilder cartContent = new StringBuilder("\n=== YOUR CART ===\n");
            for (FoodItem item : cart.getItems()) {
                cartContent.append(item.getName()).append(" - $").append(item.getPrice()).append("\n");
            }
            cartContent.append("Total: $").append(cart.calculateTotal());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Cart");
            alert.setHeaderText(null);
            alert.setContentText(cartContent.toString());
            alert.showAndWait();
        });
        
        checkoutButton.setOnAction(e -> {
            if (cart.getItems().isEmpty()) {
                statusLabel.setText("Cart is empty!");
                return;
            }
            
            double total = cart.calculateTotal();
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Checkout");
            confirm.setHeaderText("Total amount: $" + total);
            confirm.setContentText("Proceed with payment?");
            
            confirm.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    Payment payment = new Payment(1, total, "Credit Card");
                    payment.processPayment();
                    
                    Order order = new Order(1, currentCustomer, restaurant, 
                                           new java.util.ArrayList<>(cart.getItems()));
                    order.placeOrder();
                    
                    Delivery delivery = new Delivery(1, order);
                    delivery.updateStatus("Out for Delivery");
                    
                    cart.clearCart();
                    statusLabel.setText("Order placed successfully!");
                    updateMenuDisplay(menuArea);
                }
            });
        });
        
        HBox orderBox = new HBox(10, itemIdField, orderButton, viewCartButton, checkoutButton);
        orderBox.setAlignment(Pos.CENTER);
        
        VBox content = new VBox(10, welcome, description, 
                                new Label("Menu:"), menuArea, 
                                new Label("Place Order:"), orderBox, statusLabel);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(20));

        // Footer
        Label footerText = new Label("© 2026 Online Food Delivery");
        footerText.setTextFill(Color.GRAY);

        HBox footer = new HBox(footerText);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(10));

        // Root layout
        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(content);
        root.setBottom(footer);

        Scene scene = new Scene(root, 800, 600);
        stage.setTitle("Food Delivery App");
        stage.setScene(scene);
        stage.show();
    }
    
    private void setupDemoData() {
        restaurant = new Restaurant(1, "Pizza Palace", "Downtown");
        restaurant.addFoodItem(new FoodItem(1, "Margherita Pizza", 12.99, "Pizza", true));
        restaurant.addFoodItem(new FoodItem(2, "Pepperoni Pizza", 14.99, "Pizza", true));
        restaurant.addFoodItem(new FoodItem(3, "Caesar Salad", 7.99, "Salad", true));
        restaurant.addFoodItem(new FoodItem(4, "Garlic Bread", 4.99, "Appetizer", true));
        
        cart = new Cart();
        currentCustomer = new Customer(1, "John Doe", "john@email.com", "pass", "123 Main St", "555-1234");
    }
    
    private void updateMenuDisplay(TextArea menuArea) {
        StringBuilder menu = new StringBuilder();
        menu.append(String.format("%-10s %-25s %-10s\n", "ID", "Item", "Price"));
        menu.append("----------------------------------------\n");
        for (FoodItem item : restaurant.getMenu()) {
            menu.append(String.format("%-10d %-25s $%-10.2f\n", 
                      item.getItemId(), item.getName(), item.getPrice()));
        }
        menuArea.setText(menu.toString());
    }
    
    private FoodItem findItemById(int id) {
        for (FoodItem item : restaurant.getMenu()) {
            if (item.getItemId() == id) {
                return item;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        launch(args);
    }
}