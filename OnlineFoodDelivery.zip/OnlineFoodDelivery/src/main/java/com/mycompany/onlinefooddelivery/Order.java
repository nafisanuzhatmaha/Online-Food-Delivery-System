package com.mycompany.onlinefooddelivery;

import java.util.ArrayList;

public class Order {
    private int orderId;
    private Customer customer;
    private Restaurant restaurant;
    private ArrayList<FoodItem> items;
    private double totalPrice;
    private String status;

    public Order(int orderId, Customer customer, Restaurant restaurant,
                 ArrayList<FoodItem> items) {
        this.orderId = orderId;
        this.customer = customer;
        this.restaurant = restaurant;
        this.items = items;
        this.totalPrice = calculateTotal();
        this.status = "Pending";
    }

    private double calculateTotal() {
        double total = 0;
        for (FoodItem item : items) {
            total += item.getPrice();
        }
        return total;
    }

    public void placeOrder() {
        status = "Placed";
        System.out.println("Order placed successfully. Total: $" + totalPrice);
    }

    public void cancelOrder() {
        status = "Cancelled";
        System.out.println("Order cancelled.");
    }

    public double getTotalPrice() {
        return totalPrice;
    }
    
    public String getStatus() {
        return status;
    }
    
    public int getOrderId() {
        return orderId;
    }
}