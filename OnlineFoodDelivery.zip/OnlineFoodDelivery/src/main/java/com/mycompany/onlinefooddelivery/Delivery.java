package com.mycompany.onlinefooddelivery;

public class Delivery {
    private int deliveryId;
    private Order order;
    private DeliveryAgent deliveryAgent;
    private String deliveryStatus;

    public Delivery(int deliveryId, Order order) {
        this.deliveryId = deliveryId;
        this.order = order;
        this.deliveryStatus = "Preparing";
    }

    public void assignAgent(DeliveryAgent agent) {
        this.deliveryAgent = agent;
        System.out.println("Delivery agent assigned: " + agent.getName());
    }

    public void updateStatus(String status) {
        this.deliveryStatus = status;
        System.out.println("Delivery status updated to: " + status);
    }
    
    public String getDeliveryStatus() {
        return deliveryStatus;
    }
}