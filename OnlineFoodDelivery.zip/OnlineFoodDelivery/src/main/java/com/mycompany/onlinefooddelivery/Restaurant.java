package com.mycompany.onlinefooddelivery;

import java.util.ArrayList;

public class Restaurant {
    private int restaurantId;
    private String name;
    private String location;
    private ArrayList<FoodItem> menu = new ArrayList<>();

    public Restaurant(int restaurantId, String name, String location) {
        this.restaurantId = restaurantId;
        this.name = name;
        this.location = location;
    }

    public void addFoodItem(FoodItem item) {
        menu.add(item);
    }

    public void removeFoodItem(FoodItem item) {
        menu.remove(item);
    }

    public String getName() {
        return name;
    }
    
    public ArrayList<FoodItem> getMenu() {
        return menu;
    }
    
    public String getLocation() {
        return location;
    }
}