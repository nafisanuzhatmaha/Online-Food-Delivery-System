package com.mycompany.onlinefooddelivery;

public class Payment {
    private int paymentId;
    private double amount;
    private String paymentMethod;
    private String paymentStatus;

    public Payment(int paymentId, double amount, String paymentMethod) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = "Pending";
    }

    public void processPayment() {
        paymentStatus = "Completed";
        System.out.println("Payment successful: $" + amount + " via " + paymentMethod);
    }
    
    public String getPaymentStatus() {
        return paymentStatus;
    }
}