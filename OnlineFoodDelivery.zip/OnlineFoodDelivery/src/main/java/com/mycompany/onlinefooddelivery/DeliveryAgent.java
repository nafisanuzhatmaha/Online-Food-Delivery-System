package com.mycompany.onlinefooddelivery;

public class DeliveryAgent extends User {
    private String vehicleType;
    private boolean availabilityStatus;

    public DeliveryAgent(int userId, String name, String email, String password,
                         String vehicleType, boolean availabilityStatus) {
        super(userId, name, email, password);
        this.vehicleType = vehicleType;
        this.availabilityStatus = availabilityStatus;
    }

    public void acceptDelivery() {
        System.out.println(name + " accepted delivery.");
    }

    public void updateDeliveryStatus() {
        System.out.println("Delivery status updated.");
    }
    
    public boolean isAvailable() {
        return availabilityStatus;
    }
}