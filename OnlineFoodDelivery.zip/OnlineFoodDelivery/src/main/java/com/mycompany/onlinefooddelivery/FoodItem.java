package com.mycompany.onlinefooddelivery;

public class FoodItem {
    private int itemId;
    private String name;
    private double price;
    private String category;
    private boolean availability;

    public FoodItem(int itemId, String name, double price,
                    String category, boolean availability) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
        this.category = category;
        this.availability = availability;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
    
    public int getItemId() {
        return itemId;
    }
    
    public String getCategory() {
        return category;
    }
    
    public boolean isAvailable() {
        return availability;
    }
}