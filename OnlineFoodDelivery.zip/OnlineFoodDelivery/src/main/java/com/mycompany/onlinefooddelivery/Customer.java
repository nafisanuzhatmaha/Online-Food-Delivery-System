package com.mycompany.onlinefooddelivery;

public class Customer extends User {
    private String address;
    private String phone;

    public Customer(int userId, String name, String email, String password,
                    String address, String phone) {
        super(userId, name, email, password);
        this.address = address;
        this.phone = phone;
    }

    public void placeOrder() {
        System.out.println(name + " placed an order.");
    }

    public void viewOrderHistory() {
        System.out.println("Viewing order history...");
    }
    
    public String getAddress() {
        return address;
    }
    
    public String getPhone() {
        return phone;
    }
}