package com.mycompany.onlinefooddelivery;

import java.util.ArrayList;

public class Cart {
    private ArrayList<FoodItem> cartItems = new ArrayList<>();

    public void addItem(FoodItem item) {
        cartItems.add(item);
        System.out.println("Added to cart: " + item.getName());
    }

    public void removeItem(FoodItem item) {
        cartItems.remove(item);
        System.out.println("Removed from cart: " + item.getName());
    }

    public double calculateTotal() {
        double total = 0;
        for (FoodItem item : cartItems) {
            total += item.getPrice();
        }
        return total;
    }

    public ArrayList<FoodItem> getItems() {
        return cartItems;
    }
    
    public void clearCart() {
        cartItems.clear();
    }
}